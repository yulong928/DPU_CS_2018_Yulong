#include "conio.h"
#include "graphics.h"
#include "math.h"
double f[3][3];
void FillColor(int x,int y,int FColor,int BColor)
{
	if(getpixel(x,y)!=FColor&&getpixel(x,y)!=BColor)
	{
		putpixel(x,y,BColor);
		FillColor(x+1,y,FColor,BColor);
		FillColor(x-1,y,FColor,BColor);
		FillColor(x,y+1,FColor,BColor);
		FillColor(x,y-1,FColor,BColor);
	}

}
void PingYi(int x[],int y[],int x_py,int y_py)
{
	int i;
	for(i=0;i<12;i++)
	{
		setcolor(5);
		line(x[i]+x_py,y[i]+y_py,x[i+1]+x_py,y[i+1]+y_py);
	}
}
void Bili(int x[],int y[],double x_bl,double y_bl)
{
	int i;
	for(i=0;i<12;i++)
	{
		setcolor(9);
		line((int)(x[i]*x_bl),(int)(y[i]*y_bl),(int)(x[i+1]*x_bl),(int)(y[i+1]*y_bl));
	}
}
void XuanZhuan(int x[],int y[],double xz)
{
	int i;
	double xx[13],yy[13];
	f[0][0]=xz;f[0][1]=sqrt(1-(xz*xz));f[0][2]=0;
	f[1][0]=0-sqrt(1-(xz*xz));f[1][1]=xz;f[1][2]=0;
	f[2][0]=0;f[2][1]=0;f[2][2]=1;
	for(i=0;i<13;i++)
	{
		xx[i]=x[i]*f[0][0]+y[i]*f[1][0]+1*f[2][0];
		yy[i]=x[i]*f[0][1]+y[i]*f[1][1]+1*f[2][1];
	}
	setcolor(10);
	for(i=0;i<12;i++)
	{
		line((int)(xx[i]),(int)(yy[i]),(int)(xx[i+1]),(int)(yy[i+1]));
	}
}
void main()
{
	int i,lColor=4,bColor=2;
	int x_py,y_py;
	double x_bl,y_bl,xz;
	int x[13]={170,170,195,195,173,173,195,195,170,170,210,210,170};
	int y[13]={160,170,170,185,185,200,200,215,215,225,225,160,160};
    int graphdriver=DETECT,graphmode;           /*�Զ�������ʾ�����ͺ���ʾģʽ*/
    initgraph(&graphdriver,&graphmode," ");
	for(i=0;i<12;i++)
	{
		setcolor(lColor);
		line(x[i],y[i],x[i+1],y[i+1]);
	}
	FillColor(200,190,lColor,bColor);
	printf("������ƽ�����꣺\n");
	scanf("%d %d",&x_py,&y_py);
	PingYi(x,y,x_py,y_py);
	printf("�������������꣺\n");
	scanf("%lf %lf",&x_bl,&y_bl);
	Bili(x,y,x_bl,y_bl);

	printf("��������ת�Ƕȣ�\n");
	scanf("%lf",&xz);
	XuanZhuan(x,y,xz);
    getch();
    closegraph();
}