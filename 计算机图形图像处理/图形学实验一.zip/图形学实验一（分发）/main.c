#include "graphics.h"
void TheLineDDA(int x0,int y0,int x1,int y1)
{
	int temp;
	float m;
	float x,y;
	x=(float)x0;
	y=(float)y0;
	m=(float)(y1-y0)/(x1-x0);
	if(m>1)
	{
		m=1/m;
		for(;y<=y1;y++)
		{
			putpixel((int)(x+0.5),(int)y,5);
			x+=m;
		}
	}
	else{
		for(;x<=x1;x++)
		{
			putpixel((int)x,(int)(y+0.5),5);
			y+=m;
		}
	}
}

void MidpointLine(int x0,int y0,int x1,int y1)
{
	int a,b,d1,d2,d,x,y;
	int temp;
	if(x0>x1)
	{
		temp=x0;x0=x1;x1=temp;
		temp=y0;y0=y1;y1=temp;
	}
	a=y0-y1;b=x1-x0;d=a+a+b;
	d1=2*a;d2=2*(a+b);
	x=x0;y=y0;
	putpixel(x,y,3);
	if (y1>y0)
	{
		for(;x<x1;)
		{
			if(d<0){
				x+=1;y-=1;d+=d2;
			}
			else{
				x+=1;d+=d1;
			}
			putpixel(x,y,3);
		}	
	}
	else
	{
		for(;x<x1;)
		{
			if(d<0){
				x+=1;y+=1;d+=d2;
			}
			else{
				x+=1;d+=d1;
			}
			putpixel(x,y,3);
		}	
	}
}
void BresenhamLine(int x0,int y0,int x1,int y1)
{
	int dx,dy,p;
	int y=y0,x=x0;
	dx=x1-x0;
	dy=y1-y0;
	p=2*dy-dx;
	putpixel(x,y,9);
	if(y1>y0)
	{
		while(x<x1)
		{
			x++;
			if(p>0){
				y++;
			}
			putpixel(x,y,9);
			if(p>0){
				p=p+2*dy-2*dx;
			}
			else{
				p=p+2*dy;
			}
		}
	}
	else
	{
		while(x<x1)
		{
			x++;
			if(p>0){
				y--;
			}
			putpixel(x,y,9);
			if(p>0){
				p=p+2*dy-2*dx;
			}
			else{
				p=p+2*dy;
			}
		}
	}
}
pointCircle(int x_center,int y_center,int x,int y,int color)
{
	putpixel(x+x_center,y+y_center,color);
	putpixel(y+x_center,x+y_center,color);
	putpixel(x_center-x,y+y_center,color);
	putpixel(x+x_center,y_center-y,color);
	putpixel(x_center+y,y_center-x,color);
	putpixel(x_center-y,y_center+x,color);
	putpixel(x_center-x,y_center-y,color);
	putpixel(x_center-y,y_center-x,color);

}
void MidpointCircle(int x_center,int y_center,int r){
	int x,y;
	float d;
	x=0;y=r;d=1.25-r;
	//x,y; y,x; x,-y; -y,x; -x,y; y,-x; -x,-y; -y,-x;
	pointCircle(x_center,y_center,x,y,7);
	while(x<y){
		if(d<0){
			d+=2*x+3;
			x++;
		}
		else{
			d+=2*(x-y)+5;
			x++;
			y--;
		}
		pointCircle(x_center,y_center,x,y,7);
	}
}
void PositiveCircle(int x_center,int y_center,int r)
{
	int x,y,d;
	x=0;y=r;
	pointCircle(x_center,y_center,x,y,8);
	x=1;
	pointCircle(x_center,y_center,x,y,8);
	d=1;
	while(y>=x)
	{
		
		if(d>=0)
		{

			d=d-2*y+1;
			y--;
		}
		else{
			d=d+2*x+1;
			x++;
		}
		pointCircle(x_center,y_center,x,y,8);
	}
	
}
main(){
	int x0,y0,x1,y1,r;
	int graphdrive = DETECT,graphmode;
	initgraph(&graphdrive,&graphmode,"");
	MidpointCircle(269,101,30);
	BresenhamLine(164,146,256,148);
	TheLineDDA(256,148,295,179);
	MidpointLine(295,179,355,185);
	MidpointCircle(375,185,20);
	TheLineDDA(205,243,256,148);
	BresenhamLine(132,240,205,243);
	MidpointLine(231,209,279,231);
	TheLineDDA(279,231,295,293);
	getch();
	closegraph();
}
