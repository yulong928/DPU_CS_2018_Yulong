﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Drawing.Imaging;

namespace WindowsFormsApplication2
{

    public partial class Form1 : Form
    {
        private string curFileName;
        private Image curImage;
        double[] pro = new double[256];

        public Form1()
        {
            InitializeComponent();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            OpenFileDialog fileDg = new OpenFileDialog();
            if (fileDg.ShowDialog() == DialogResult.OK)
            {
                curFileName = fileDg.FileName;
                curImage = Image.FromFile(curFileName);
            }
            this.Invalidate();
        }
        protected override void OnPaint(PaintEventArgs e)
        {
            //base.OnPaint(e);
            try
            {
                e.Graphics.DrawImage(curImage,10,10,curImage.Width, curImage.Height);
            }
            catch
            {

            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form2 fm2 = new Form2();
            fm2.Show();
            double[] seq = new double[256];
            Graphics g = fm2.CreateGraphics();
            Bitmap cImage = new Bitmap(curImage, new Size(curImage.Height, curImage.Width));
            Bitmap sImage = new Bitmap(curImage.Height, curImage.Width);
            Rectangle lockedRect = new Rectangle(0, 0, cImage.Width, cImage.Height);
            BitmapData srcData = cImage.LockBits(lockedRect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            BitmapData dstData = sImage.LockBits(lockedRect, ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            unsafe
            {
                byte* src = (byte*)srcData.Scan0;
                byte* dst = (byte*)dstData.Scan0;
                int offset = srcData.Stride - cImage.Width * 3;
                for(int y=0;y<cImage.Height;y++)
                {
                    for(int x=0;x<cImage.Width;x++)
                    {
                        dst[0] = dst[1] = dst[2] = (byte)((src[0] + src[1] + src[2]) / 3);
                        seq[*dst]++;
                        src += 3;
                        dst += 3;
                    }
                    src += offset;
                    dst += offset;
                }
                double total = 0;
                double max = 0.0;
                for(int i=0;i<256;i++)
                {
                    total = total + seq[i];
                    if (max < seq[i])
                        max = seq[i];
                }
                Pen rpen = new Pen(Color.Blue, 1);
                int yz;
                for(int i=0;i<256;i++)
                {
                    pro[i] = seq[i] / total;
                    yz = (int)(192 * (1 - seq[i] / max));
                    g.DrawLine(rpen, i, yz, i, 192);

                }
            }
            cImage.UnlockBits(srcData);
            sImage.UnlockBits(dstData);
            g.Save();
            g.Dispose();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form3 fm3 = new Form3();
            fm3.Show();
            Form4 fm4 = new Form4();
            fm4.Show();
            Graphics g = fm3.CreateGraphics();
            Graphics g2 = fm4.CreateGraphics();
            byte[] L = new byte[256];
            double[] S = new double[256];
            for(int i=0;i<256;i++)
            {
                if(i==0)
                {
                    S[0] = pro[0];
                }
                else
                {
                    S[i] = S[i - 1] + pro[i];
                }
                L[i] = (byte)(255 * S[i]);
            }
            Bitmap cImage = new Bitmap(curImage, new Size(curImage.Height, curImage.Width));
            Bitmap sImage = new Bitmap(curImage.Height, curImage.Width);
            Rectangle lockedRect = new Rectangle(0, 0, cImage.Width, cImage.Height);
            BitmapData srcData = cImage.LockBits(lockedRect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            BitmapData dstData = sImage.LockBits(lockedRect, ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            unsafe
            {
                byte* src = (byte*)srcData.Scan0;
                byte* dst = (byte*)dstData.Scan0;
                double[] seq = new double[256];
                int offset = srcData.Stride - cImage.Width * 3;
                for (int y = 0; y < sImage.Height; y++)
                {
                    for (int x = 0; x < sImage.Width; x++)
                    {
                        dst[0] = dst[1] = dst[2] = (byte)((src[0] + src[1] + src[2]) / 3);
                        dst[0] = dst[1] = dst[2] = L[dst[0]];
                        seq[*dst]++;
                        src += 3;
                        dst += 3;
                    }
                    src += offset;
                    dst += offset;
                }
                double total = 0;
                double max = 0.0;
                for (int i = 0; i < 256; i++)
                {
                    total = total + seq[i];
                    if (max < seq[i])
                        max = seq[i];
                }
                Pen rpen = new Pen(Color.Red, 1);
                int yz;
                for (int i = 0; i < 256; i++)
                {
                    pro[i] = seq[i] / total;
                    yz = (int)(192 * (1 - seq[i] / max));
                    g2.DrawLine(rpen, i, yz, i, 192);

                }
            }
            cImage.UnlockBits(srcData);
            sImage.UnlockBits(dstData);
            g.DrawImage(sImage, 10, 10, sImage.Height, sImage.Width);
            g.Save();
            g.Dispose();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Form5 fm5 = new Form5();
            fm5.Show();
            Graphics g = fm5.CreateGraphics();
            byte[] L = new byte[256];
            double[] S = new double[256];
            for (int i = 0; i < 256; i++)
            {
                if (i == 0)
                {
                    S[0] = pro[0];
                }
                else
                {
                    S[i] = S[i - 1] + pro[i];
                }
                L[i] = (byte)(255 * S[i]);
            }
            Bitmap cImage = new Bitmap(curImage, new Size(curImage.Height, curImage.Width));
            Bitmap sImage = new Bitmap(curImage.Height, curImage.Width);
            Rectangle lockedRect = new Rectangle(0, 0, cImage.Width, cImage.Height);
            BitmapData srcData = cImage.LockBits(lockedRect, ImageLockMode.ReadOnly, PixelFormat.Format24bppRgb);
            BitmapData dstData = sImage.LockBits(lockedRect, ImageLockMode.ReadWrite, PixelFormat.Format24bppRgb);
            unsafe
            {
                byte* src = (byte*)srcData.Scan0;
                byte* dst = (byte*)dstData.Scan0;
                double[] seq = new double[256];
                int offset = srcData.Stride - cImage.Width * 3;
                for (int y = 0; y < sImage.Height; y++)
                {
                    for (int x = 0; x < sImage.Width; x++)
                    {
                        dst[0]= (byte)(src[0]);
                        dst[1] = (byte)(src[1]);
                        dst[2] = (byte)(src[2]);
                        dst[0] = L[dst[0]];
                        dst[1] = L[dst[1]];
                        dst[2] = L[dst[2]];
                        seq[*dst]++;
                        src += 3;
                        dst += 3;
                    }
                    src += offset;
                    dst += offset;
                }
                double total = 0;
                double max = 0.0;
                for (int i = 0; i < 256; i++)
                {
                    total = total + seq[i];
                    if (max < seq[i])
                        max = seq[i];
                }
                Pen rpen = new Pen(Color.Red, 1);
                int yz;
                for (int i = 0; i < 256; i++)
                {
                    pro[i] = seq[i] / total;
                    yz = (int)(192 * (1 - seq[i] / max));
                }
            }
            cImage.UnlockBits(srcData);
            sImage.UnlockBits(dstData);
            g.DrawImage(sImage, 10, 10, sImage.Height, sImage.Width);
            g.Save();
            g.Dispose();
        }
    }
}
