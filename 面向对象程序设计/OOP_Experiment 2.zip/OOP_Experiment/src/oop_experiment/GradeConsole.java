/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;
//通过重写Console中输入整型数值方法，使输入成绩时保证成绩在0~100间。
public class GradeConsole extends Console{
    static int num;
    public static int inputInt(){
        num = Console.inputInt();
        while(num<0||num>100){
            System.out.println("输入信息有误，请核对后重新输入：");
            num = Console.inputInt();
        }
        return num;
    }
}
