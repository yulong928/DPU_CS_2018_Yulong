/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;

/**
 *
 * @author yulon
 */
//构造学生-课程类
public class SC {
    private String SNo;
    private String CNo;
    private int Grade;
    private double Gredit;
    //构造方法
    public SC (String SNo,String CNo){
        this.SNo = SNo;
        this.CNo = CNo;
    }
    
    public SC (String SNo,String CNo,int Grade,double Gredit){
        this.SNo = SNo;
        this.CNo = CNo;
        this.Grade = Grade;
        this.Gredit = Gredit;
    }
    //getter和setter方法
    public String getSNo(){
        return SNo;
    }
    public String getCNo(){
        return CNo;
    }
    public int getGrade(){
        return Grade;
    }
    public double getGredit(){
        return Gredit;
    }
    public void setSNo(String SNo){
        this.SNo = SNo;
    }
    public void setCNo(String CNo){
        this.CNo = CNo;
    }
    public void setGrade(int Grade){
        this.Grade = Grade;
    }
    public void setGredit(double Gredit){
        this.Gredit = Gredit;
    }
}
