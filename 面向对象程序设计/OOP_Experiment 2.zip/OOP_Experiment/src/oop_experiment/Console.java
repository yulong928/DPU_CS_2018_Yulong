/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;

/**
 *
 * @author yulon
 */
import java.util.Scanner;
public class Console {
    public static String inputString(){
        Scanner scanner = new Scanner(System.in);
        String str = scanner.next();
        return str;
    }
    public static int inputInt(){
        Scanner scanner = new Scanner(System.in);
        int num = scanner.nextInt();
        return num;
    }
}
