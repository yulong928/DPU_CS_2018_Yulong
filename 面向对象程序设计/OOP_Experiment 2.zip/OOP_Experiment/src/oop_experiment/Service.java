/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;

/**
 *
 * @author yulon
 */
//服务部分
public class Service {
    //从文件中获取学生信息
    public static Student SearchStu(){
        System.out.println("\n请输入学生姓名:");
        String StuName = Console.inputString();
        Student stu = Manager.stuManager(StuName);
        return stu;
    }
    //服务界面
    public static void servise(int service){
        while(service!=0){
            switch (service) {
                case 1:
                    Student stu1 = SearchStu();
                    if(stu1==null){
                        System.out.println("\n无该学生成绩！请重新选择操作：");
                        serviseTip();
                        service = Console.inputInt();
                    }
                    else{
                        System.out.println("\n请输入查询密钥：");
                        String password = Console.inputString();
                        if(stu1.getPassword().equals(password)){
                            System.out.println("\n该学生成绩为：");
                            Manager.stuGrade(stu1.getStuNum());
                            GPAManager.getGPA(stu1);
                            System.out.println("\n查询结束，请选择操作：");
                            serviseTip();
                            service = Console.inputInt();
                        }
                        else{
                            System.out.println("\n密钥错误，请重新选择操作：");
                            serviseTip();
                            service = Console.inputInt();
                        }
                    }
                    break;
                case 2:
                    System.out.println("\n请输入您的工号：");
                    String teacherNum = Console.inputString();
                    Teacher teacher1 = Manager.getTeacher(teacherNum);
                    if(teacher1!=null){
                        System.out.println("\n"+teacher1.getTeacherName()+"老师您好，请输入您的密码：");
                        String password = Console.inputString();
                        if(password.equals(teacher1.getPassword())){
                            int tf = ChangeGrade(teacher1.getTeacherNum());
                            if(tf == 1){
                                System.out.println("\n更改成功，请选择操作：");
                                serviseTip();
                                service = Console.inputInt();
                            }
                            else if(tf==2){
                                System.out.println("\n您无权修改该学科成绩，请选择操作：");
                                serviseTip();
                                service = Console.inputInt();
                            }
                            else{
                                System.out.println("\n更改失败，请选择操作：");
                                serviseTip();
                                service = Console.inputInt();
                            }
                        }
                        else{
                            System.out.println("\n密码输入错误，请选择操作：");
                            serviseTip();
                            service = Console.inputInt();
                        }
                    }
                    else{
                        System.out.println("\n未查询到您的信息，请选择操作：");
                        serviseTip();
                        service = Console.inputInt();
                    }
                    break;
                default:
                    System.out.println("\n非法输入，请重新选择");
                    serviseTip();
                    service = Console.inputInt();
                    break;
            }
        }
        System.out.println("正在退出系统···");
    }
    //服务提示界面
    public static void serviseTip(){
        System.out.println("1.成绩查询");
        System.out.println("2.成绩修改");
        System.out.println("0.退出系统");
    }
    //更改成绩函数
    public static int ChangeGrade(String teacherNum){
        int tf;
        System.out.println("\n请输入课程号");
        String CourseNum = Console.inputString();
        if(teacherNum.equals(Manager.getAimTeacher(CourseNum))){
            Student stu2 = SearchStu();
            System.out.println("\n请输入平时成绩");
            int grade1 = GradeConsole.inputInt();
            System.out.println("\n请输入期末成绩");
            int grade2 = GradeConsole.inputInt();
            int grade = (int)(grade1 * 0.4 + grade2 * 0.6);
            double Gredit;
            if(grade>=90){
                Gredit = 4;
            }
            else if(grade>=80&&grade<90){
                Gredit = 3;
            }
            else if(grade>=70&&grade<80){
                Gredit = 2;
            }
            else if(grade>=60&&grade<70){
                Gredit = 1;
            }
            else{
                Gredit = 0;
            }
            tf = Manager.ChangeGrade(stu2.getStuNum(),CourseNum,grade,Gredit);
        }
        else{
            tf=2;
        }
        return tf;
    }
}
