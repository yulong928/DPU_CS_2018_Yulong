package oop_experiment;
import java.math.*;
public class GPAManager extends Manager{
    static Student stu1 = new Student();
    static double gpa;
    public static void getGPA(Student stu1){
        gpa = figureGPA(stu1.getStuNum());
        //实现绩点保留小数点后2位数
        BigDecimal b = new BigDecimal(gpa);  
        double f1 = b.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
        System.out.println("该生平均成绩绩点为："+ f1);
    }
    public static double figureGPA(String StuNum){
        double sum = 0,ave = 0;
        String content = FileTool.read("SC-lab.txt");
        String[] lines = content.split("\r\n");
        scs = new SC[lines.length];
        for(int i=0;i<lines.length;i++){
            String[] items = lines[i].split(",");
            scs[i] = new SC(items[0],items[1],Integer.parseInt(items[2]),Double.valueOf(items[3]));
            if(scs[i].getSNo().equals(StuNum)){
                sum += scs[i].getGredit() * getCourseCredit(scs[i].getCNo());
                ave += getCourseCredit(scs[i].getCNo());
            }
        }
        sum = sum/ave;
        return sum;
    }
    public static double getCourseCredit(String CourseNum){
        String content = FileTool.read("Course-lab.txt");
        String[] lines = content.split("\r\n");
        courses = new Course[lines.length];
        for(int i=0;i<courses.length;i++){
            String[] items = lines[i].split(",");
            courses[i] = new Course(items[0],items[1],Double.valueOf(items[2]));
            if(courses[i].getCourseNum().equals(CourseNum)){
                return courses[i].getCredit();
            }
        }
        return 0;
    }
}
