package oop_experiment;
//主函数，进入程序
public class OOP_Experiment {
    public static void main(String[] args) {
        System.out.println("请选择服务项目");
        Service.serviseTip();
        int service = Console.inputInt();
        Service.servise(service);
    }
}

