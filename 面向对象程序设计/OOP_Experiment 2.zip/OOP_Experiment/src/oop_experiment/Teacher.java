/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;

import static oop_experiment.Manager.courses;

/**
 *
 * @author yulon
 */
//构建老师类
public class Teacher {
    private String teacherNum;
    private String teacherName;
    private String password;
    public Teacher(String teacherNum, String teacherName, String password){
        this.teacherNum = teacherNum;
        this.teacherName = teacherName;
        this.password = password;
    }
    public String getTeacherNum(){
        return teacherNum;
    }
    public String getTeacherName(){
        return teacherName;
    }
    public String getPassword(){
        return password;
    }
}
