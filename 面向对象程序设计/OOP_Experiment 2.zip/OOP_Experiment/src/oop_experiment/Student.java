/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;

/**
 *
 * @author yulon
 */
//构建学生类
public class Student {
    private String stuNum;              //学号
    private String stuName;             //学生姓名
    private String password;
    //构造方法
    public Student(){
        
    }
    public Student(String stuNum){
        this.stuNum = stuNum;
    }
    public Student(String stuNum,String stuName){
        this.stuNum = stuNum;
        this.stuName = stuName;
    }
    public Student(String stuNum,String stuName,String password){
        this.stuNum = stuNum;
        this.stuName = stuName;
        this.password = password;
    }
     //getter和setter方法
    public String getStuNum(){
        return stuNum;
    }
    public String getStuName(){
        return stuName;
    }
    public String getPassword(){
        return password;
    }
    public void setStuNum(String stuNum){
        this.stuNum = stuNum;
    }
    public void setStuName(String stuName){
        this.stuName = stuName;
    }
}
