/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;
//构建信息检索相关方法
public class Manager {
    static Student[] students;
    static SC[] scs;
    static Course[] courses;
    //通过学生姓名检索该学生对象
    public static Student stuManager(String StuName){
        String content = FileTool.read("stu-lab.txt");
        String[] lines = content.split("\r\n");
        students = new Student[lines.length];
        for(int i=0;i<lines.length;i++){
            String[] items = lines[i].split(",");
            students[i] = new Student(items[0],items[1],items[2]);
            if(students[i].getStuName().equals(StuName)){
                return students[i];
            }
        }
        return null;
    }
    //通过学生学号检索学生各学科成绩
    public static void stuGrade(String StuNum){
        String content = FileTool.read("SC-lab.txt");
        String[] lines = content.split("\r\n");
        scs = new SC[lines.length];
        for(int i=0;i<lines.length;i++){
            String[] items = lines[i].split(",");
            scs[i] = new SC(items[0],items[1],Integer.parseInt(items[2]),Double.valueOf(items[3]));
            if(scs[i].getSNo().equals(StuNum)){
                System.out.println(getCourseName(scs[i].getCNo())+"\t"+scs[i].getGrade());
            }
        }
    }
    //通过课程号检索课程名称
    public static String getCourseName(String CourseNum){
        String content = FileTool.read("Course-lab.txt");
        String[] lines = content.split("\r\n");
        courses = new Course[lines.length];
        for(int i=0;i<courses.length;i++){
            String[] items = lines[i].split(",");
            courses[i] = new Course(items[0],items[1],items[2],Double.valueOf(items[3]));
            if(courses[i].getCourseNum().equals(CourseNum)){
                return courses[i].getCourseName();
            }
        }
        return null;
    }
    //修改成绩函数，成功返回值为1，不成功返回数值0
    public static int ChangeGrade(String StuNum,String CourseNum,int Grade,double Gredit){
        int tf = 0;
        String content = FileTool.read("SC-lab.txt");
        String[] lines = content.split("\r\n");
        scs = new SC[lines.length];
        for(int i=0;i<lines.length;i++){
            String[] items = lines[i].split(",");
            scs[i] = new SC(items[0],items[1],Integer.parseInt(items[2]),Double.valueOf(items[3]));
            if(scs[i].getSNo().equals(StuNum)){
                if (scs[i].getCNo().equals(CourseNum)) {
                    scs[i].setGrade(Grade);
                    scs[i].setGredit(Gredit);
                    tf = 1;
                }
            }
        }
        String contents = "";
        for (SC sc : scs) {
            contents += sc.getSNo() + "," + sc.getCNo() + "," + sc.getGrade() + "," + sc.getGredit() + "\r\n";
        }
        if(tf==0){
            contents += StuNum+","+CourseNum+","+Grade+","+Gredit+"\r\n";
            tf=1;
        }
        FileTool.write("SC-lab.txt", contents);
        return tf;
    }
    public static Teacher[] teachers;
    //通过老师工号检索该老师对象。
    public static Teacher getTeacher(String TeacherNum){
        String content = FileTool.read("Teacher-lab.txt");
        String[] lines = content.split("\r\n");
        teachers = new Teacher[lines.length];
        for(int i=0;i<teachers.length;i++){
            String[] items = lines[i].split(",");
            teachers[i] = new Teacher(items[0],items[1],items[2]);
            if(teachers[i].getTeacherNum().equals(TeacherNum)){
                return teachers[i];
            }
        }
        return null;
    }
    //通过课程号检索该课程授课教师工号
    public static String getAimTeacher(String CourseNum){
        String content = FileTool.read("Course-lab.txt");
        String[] lines = content.split("\r\n");
        courses = new Course[lines.length];
        for(int i=0;i<courses.length;i++){
            String[] items = lines[i].split(",");
            courses[i] = new Course(items[0],items[1],items[2],Double.valueOf(items[3]));
            if(courses[i].getCourseNum().equals(CourseNum)){
                return courses[i].getTeacherNum();
            }
        }
        return null;
    }
}