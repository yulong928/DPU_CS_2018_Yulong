/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oop_experiment;
/**
 *
 * @author yulon
 */
//构建课程类
public class Course {
    private String courseNum;
    private String courseName;
    private String teacher;
    private double credit;
    //构造方法
    public Course(String courseNum){
        this.courseNum = courseNum;
    }
    public Course(String courseNum,String courseName,double credit){
        this.courseNum = courseNum;
        this.courseName = courseName;
        this.credit = credit;
    }
    public Course(String courseNum,String courseName,String teacher,double credit){
        this.courseNum = courseNum;
        this.courseName = courseName;
        this.teacher = teacher;
        this.credit = credit;
    }
    //各个变量的getter和setter
    public String getCourseNum(){
        return courseNum;
    }
    public String getCourseName(){
        return courseName;
    }
    public double getCredit(){
        return credit;
    }
    public String getTeacherNum(){
        return teacher;
    }
    public void setCourseNum(String courseNum){
        this.courseNum = courseNum;
    }
    public void setCourseName(String courseName){
        this.courseName = courseName;
    }
    public void setCredit(double credit){
        this.credit = credit;
    }
}
